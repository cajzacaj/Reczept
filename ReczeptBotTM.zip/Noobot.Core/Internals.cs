﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Noobot.Tests.Unit")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]