﻿namespace Noobot.Core.DependencyResolution
{
    public interface IContainerFactory
    {
        INoobotContainer CreateContainer();
    }
}