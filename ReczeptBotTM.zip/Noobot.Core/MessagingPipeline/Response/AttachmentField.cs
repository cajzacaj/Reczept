﻿namespace Noobot.Core.MessagingPipeline.Response
{
    public class AttachmentField
    {
        public string Title { get; set; }
        public string Value { get; set; }
        public bool IsShort { get; set; }
    }
}