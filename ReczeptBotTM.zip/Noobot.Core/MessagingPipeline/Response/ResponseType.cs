﻿namespace Noobot.Core.MessagingPipeline.Response
{
    public enum ResponseType
    {
        Channel,
        DirectMessage
    }
}