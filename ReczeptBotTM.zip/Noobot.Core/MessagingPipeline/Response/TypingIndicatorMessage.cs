﻿namespace Noobot.Core.MessagingPipeline.Response
{
    public class TypingIndicatorMessage : ResponseMessage
    {
         
    }
}