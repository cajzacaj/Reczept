﻿namespace Noobot.Core.MessagingPipeline.Middleware
{
    public class CommandDescription
    {
        public string Command { get; set; }
        public string Description { get; set; }
    }
}