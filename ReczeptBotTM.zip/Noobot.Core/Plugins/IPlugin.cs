﻿namespace Noobot.Core.Plugins
{
    public interface IPlugin
    {
        void Start();
        void Stop();
    }
}