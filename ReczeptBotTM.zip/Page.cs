using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReczeptBot
{
    public enum Page
    {
        MainMenu, GetRecipe, EndProgram,
        LoginScreen,
        GetRecipeList,
        GetWeekMenu
    }
}
