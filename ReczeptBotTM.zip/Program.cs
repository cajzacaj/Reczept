﻿using System;

namespace ReczeptBot
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
            app.Run();
        }
    }
}
